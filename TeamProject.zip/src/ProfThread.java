import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ProfThread extends JLabel implements Runnable {
   private Thread myThread;
   private JLabel fprofessor,bprofessor; // �������� �ڵ��°�
   private GamePanel g;
   private int r;
   
   public ProfThread(GamePanel p) {
      myThread=null;
      
      g=p;
      ImageIcon originIcon = new ImageIcon("images/yohanfront.png");
      Image originImg = originIcon.getImage();
      Image changedImg = originImg.getScaledInstance(280, 600, Image.SCALE_SMOOTH);
      ImageIcon prof = new ImageIcon(changedImg);
      fprofessor = new JLabel(prof);
      fprofessor.setBounds(1400,20,250,600);
      fprofessor.setBackground(Color.black);
      g.add(fprofessor);
      fprofessor.setVisible(false);
       
      ImageIcon originybIcon = new ImageIcon("images/yohanback.png");
      Image originybImg = originybIcon.getImage();
      Image changedybImg = originybImg.getScaledInstance(280, 600, Image.SCALE_SMOOTH);
      ImageIcon profyb = new ImageIcon(changedybImg);
      bprofessor = new JLabel(profyb);
      bprofessor.setBounds(1400,20,250,600);
      bprofessor.setBackground(Color.black);
      g.add(bprofessor);
   }
   
   public void start() {
      myThread=new Thread(this);
      myThread.start();
   }//�������̵�
   
   public void stop() {
      if(myThread!=null) myThread.stop();// stop��������
   }
      
   public void run() {
      try {
         while(g.getCurrentTime()!=0){
            //Ÿ�̸Ӻ����� 0�� �Ƕ����� while��
            r=(int)(Math.random()*100)+1;
            fprofessor.setVisible(false);
            bprofessor.setVisible(true);

            myThread.sleep(r*50);
           
            r=(int)(Math.random()*100)+1;
               if(r<g.getBackRandom()) {
                  fprofessor.setVisible(true);
                   bprofessor.setVisible(false);
                   myThread.sleep(500);
                   r=(int)(Math.random()*g.getBackRandom())+1;
                  for(int j=0;j<r*50;j++) {
                     if(g.getFlag()==1) {
                    	 g.subControl();
                     }
                     myThread.sleep(1);
                     // �̶�  setMain���� �����°� ������
                  }
                  //�� flag==1 �϶��� ������ �ڵ��� ������ game over
                  //for�� �ȿ��� �� �ð��� �ɰ��� ���߰� ���  ƴƴ�� Ȯ������
   
                  r=(int)(Math.random()*100)+1;
                  fprofessor.setVisible(false);
                  bprofessor.setVisible(true);

                  myThread.sleep(r*50);
               }
         }         
      }catch(Exception e) {}
   }
}